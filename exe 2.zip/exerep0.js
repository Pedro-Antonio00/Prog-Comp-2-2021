function exe0(){
    let soma = 0
    let i = 1

    while(i <= 10){
        let nota = Number(prompt(`Informe a nota`))

        soma = soma + nota

        i++
    }
    let media = soma/10
    alert(`A média das notas é ${media}`)
}
function exe3(){
    let i = 1
    let f1 = 0
    let f2 = 0
    let f3 = 0
    let f4 = 0
    let f5 = 0
    while(i<=8){
        let idade = Number(prompt(`Informe a idade ${i}`))
        if(idade <= 15){
            f1++
        }
        else if(idade>15 && idade<=30){
            f2++
        }
        else if(idade>30 && idade<=45){
            f3++
        }
        else if(idade>45 && idade<=60){
            f4++
        }
        else{//>60
            f5++
        }
        i++// o i precisa incrementar
    }
    alert(`Faixa 1 ${f1} \nFaixa 2 ${f2} \nFaixa 3 ${f3} \nFaixa 4 ${f4} \nFaixa 5 ${f5} \n%F1 ${f1/8*100} \n%F5 ${f5/8*100}`)// \n pula linhas
}
function exe1(){
    let a, b, c, d, aux
    
    a = Number(prompt(`Informe o Valor de A`))
    b = Number(prompt(`Informe o Valor de B`))
    c = Number(prompt(`Informe o Valor de C`))
    d = Number(prompt(`Informe o Valor de D`))

    let i = 1
    while(i<=3){
        if(a>b){
           aux = a
           a = b
           b = aux 
        }
        if(b>c){
            aux = b
            b = c
            c = aux
        }
        if(c>d){
            aux = c
            c = d
            d = aux
        }
        i++
    }
    alert(`Ordem crescente ${a} ${b} ${c} ${d} e a ordem decrescente ${d} ${c} ${b} ${a}`)
}
function exe2(){
    let qtd = 120
    let lucro
    let saida = ""
    let maior = 0
    let maiorqtd = 0
    let maiorval = 0
    let contp = 1
    let contqtd = 2
    let contlu = 4
    let contfix = 3
    for(let valor = 5;valor >= 1;valor = valor - 0.50){
        lucro = (valor*qtd) - 200
        if(lucro>maior){
            maior = lucro
            maiorqtd = qtd
            maiorval = valor
        }
        document.getElementById(`${contp}`).innerHTML = valor
        document.getElementById(`${contqtd}`).innerHTML = qtd
        document.getElementById(`${contfix}`).innerHTML = "200"
        document.getElementById(`${contlu}`).innerHTML = lucro
        contqtd = contqtd + 4
        contp = contp + 4
        contlu = contlu + 4
        contfix = contfix + 4
        qtd = qtd+26
    }
    alert(`Maior lucro ${maior} com quantidade ${maiorqtd} e valor ${maiorval} `)
}