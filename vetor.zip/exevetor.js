let exe0 = function(){
    let vet = [] //declaração do vetor
    for(let i = 0;i<5;i++){
        vet.push(Number(prompt(`Informe o valor ${i+1}`)))
    }

    for(let i = 0;i<5;i++){
        vet[i] = vet[i]+10
    }
    console.log(vet)
}
let exe1 = function(){
    let vet = []
    let vetpar = []
    let vetimpar = []
    for(let i = 0;i<6;i++){
        vet.push(Number(prompt(`Informe o valor ${i+1}`)))
    }
    for(let i = 0; i<6;i++){
        if(vet[i]%2 == 0){
            vetpar.push(vet[i])
        }
        else{
            vetimpar.push(vet[i])
        }
    }
    console.log(`Os número pares são ${vetpar} e a quantidade é ${vetpar.length}`)
}