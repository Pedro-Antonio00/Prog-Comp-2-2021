let exe0 = function(){
    let vet = [] //declaração do vetor
    for(let i = 0;i<5;i++){
        vet.push(Number(prompt(`Informe o valor ${i+1}`)))
    }

    for(let i = 0;i<5;i++){
        vet[i] = vet[i]+10
    }
    console.log(vet)
}
let exe1 = function(){
    let vet = []
    let vetpar = []
    let vetimpar = []
    for(let i = 0;i<6;i++){
        vet.push(Number(prompt(`Informe o valor ${i+1}`)))
    }
    for(let i = 0; i<6;i++){
        if(vet[i]%2 == 0){
            vetpar.push(vet[i])
        }
        else{
            vetimpar.push(vet[i])
        }
    }
    console.log(`Os número pares são ${vetpar} e a quantidade é ${vetpar.length}`)
}
//arrow function = function
//Ecma Script 6
let exe4 = () =>{
    let vet=[]
    for(let i=0;i<15;i++)
    {
        vet.push(Number(prompt(`Ifnorme o Núemro ${i+1}`)))
    }

    let po30 = []
    for(let i=0;i<15;i++)
    {
        if(vet[i] == 30)
        {
            po30.push(i)// guarda a posição i q possui o 30
        }
    }
    console.log(`As posições onde aparece, o número 30 são ${po30}`)
}
let exe5 = () =>{
    let alunoslo=[]
    for(let i=0;i<5;i++)
    {
        alunoslo.push(Number(prompt(`Informe seu código - Lógica`)))
    }
    let alunosli=[]
    for(let i=0;i<5;i++)
    {
        alunosli.push(Number(prompt(`Informe seu código - Linguagem De Programação`)))
    }
    let inter=[]
    for(let a=0;a<5;a++)
    {
        for(let i=0;i<5;i++)
        {
            if(alunoslo[a] == alunosli[i])
            {
                inter.push(alunoslo[a])
            }
        }
    }
    console.log(`Os alunos que fazem as duas disciplinas são ${inter}`)
}